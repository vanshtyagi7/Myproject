package com.demo.mono;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SimactivationPortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(SimactivationPortalApplication.class, args);
	}

}
