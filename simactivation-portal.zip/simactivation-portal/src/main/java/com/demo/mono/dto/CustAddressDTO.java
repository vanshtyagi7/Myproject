package com.demo.mono.dto;

public class CustAddressDTO {

}
