package com.demo.mono.dto;

public class SimDTO {

}
