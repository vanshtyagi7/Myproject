package com.demo.mono.entity;

public class Cust {

}
