package com.demo.mono.entity;

public class CustAddress {

}
