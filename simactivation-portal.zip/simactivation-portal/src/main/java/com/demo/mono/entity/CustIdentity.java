package com.demo.mono.entity;

public class CustIdentity {

}
