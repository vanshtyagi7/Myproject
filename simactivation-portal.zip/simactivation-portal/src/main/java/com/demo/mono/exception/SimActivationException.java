package com.demo.mono.exception;

public class SimActivationException {

}
