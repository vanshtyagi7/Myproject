package com.demo.mono.repository;

public class SimDetailsRepository {

}
