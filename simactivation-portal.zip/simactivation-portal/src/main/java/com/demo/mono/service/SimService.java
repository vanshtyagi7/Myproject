package com.demo.mono.service;

public interface SimService {

}
