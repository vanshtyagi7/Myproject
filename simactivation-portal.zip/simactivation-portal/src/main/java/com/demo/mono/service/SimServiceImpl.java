package com.demo.mono.service;

public class SimServiceImpl {

}
